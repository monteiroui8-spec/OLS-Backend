<?php

namespace App\Http\Controllers\Api\Teacher;

use App\Http\Controllers\Controller;
use App\Models\ClassGroup;
use App\Models\Exam;
use App\Models\ExamAttempt;
use App\Models\Question;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TeacherExamController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacherProfile;

        $exams = Exam::where('teacher_id', $teacher->id)
            ->with(['classGroup.course'])
            ->withCount('questions')
            ->orderByDesc('created_at')
            ->paginate($request->integer('limit', 20));

        $data = $exams->map(function (Exam $exam) {
            $attempts = ExamAttempt::where('exam_id', $exam->id)
                ->where('status', 'completed')
                ->get();

            return [
                'id'              => $exam->id,
                'title'           => $exam->title,
                'status'          => $exam->status,
                'duration'        => $exam->duration,
                'questionCount'   => $exam->questions_count,
                'classGroupId'    => $exam->class_group_id,
                'classGroupName'  => $exam->classGroup?->name ?? '—',
                'course'          => $exam->classGroup?->course?->getTitle(app()->getLocale()) ?? '—',
                'submissionsCount' => $attempts->count(),
                'totalStudents'   => $exam->classGroup?->students()->count() ?? 0,
                'avgScore'        => $attempts->count() ? round($attempts->avg('score'), 1) : null,
                'passingRate'     => $attempts->count()
                    ? round($attempts->where('passed', true)->count() / $attempts->count() * 100, 1)
                    : null,
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'total'     => $exams->total(),
                'page'      => $exams->currentPage(),
                'last_page' => $exams->lastPage(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacherProfile;

        $validated = $request->validate([
            'title' => ['required', 'string', 'max:191'],
            'class_group_id' => ['nullable', 'exists:class_groups,id'],
            'course_id' => ['nullable', 'exists:courses,id'],
            'duration' => ['required', 'integer', 'min:1'],
            'max_attempts' => ['nullable', 'integer', 'min:1'],
            'due_date' => ['nullable', 'date'],
            'pass_score' => ['nullable', 'integer', 'min:0', 'max:100'],
            'questions' => ['required', 'array', 'min:1'],
            'questions.*.text' => ['required', 'string'],
            'questions.*.type' => ['required', 'in:multiple_choice,true_false,open_text'],
            'questions.*.options' => ['required_if:questions.*.type,multiple_choice,true_false', 'array'],
            'questions.*.correct' => ['required', 'integer'],
            'questions.*.points' => ['nullable', 'integer', 'min:1'],
        ]);

        if (! empty($validated['class_group_id'])) {
            ClassGroup::where('id', $validated['class_group_id'])
                ->where('teacher_id', $teacher->id)
                ->firstOrFail();
        }

        $exam = DB::transaction(function () use ($validated, $teacher) {
            $exam = Exam::create([
                'title' => $validated['title'],
                'class_group_id' => $validated['class_group_id'] ?? null,
                'course_id' => $validated['course_id'] ?? null,
                'teacher_id' => $teacher->id,
                'duration' => $validated['duration'],
                'max_attempts' => $validated['max_attempts'] ?? 1,
                'status' => 'draft',
                'due_date' => $validated['due_date'] ?? null,
                'pass_score' => $validated['pass_score'] ?? 50,
                'total_points' => 0,
            ]);

            $totalPoints = 0;

            foreach ($validated['questions'] as $index => $q) {
                $points = $q['points'] ?? 10;
                $exam->questions()->create([
                    'text' => $q['text'],
                    'type' => $q['type'],
                    'options' => $q['options'] ?? [],
                    'correct' => $q['correct'],
                    'points' => $points,
                    'order' => $index + 1,
                ]);
                $totalPoints += $points;
            }

            $exam->update(['total_points' => $totalPoints]);

            return $exam;
        });

        $exam->load('questions');

        return response()->json([
            'id' => $exam->id,
            'title' => $exam->title,
            'status' => $exam->status,
        ], 201);
    }

    public function publish(Request $request, Exam $exam): JsonResponse
    {
        $teacher = $request->user()->teacherProfile;

        if ($exam->teacher_id !== $teacher->id) {
            return response()->json([
                'message' => 'Acesso negado.',
            ], 403);
        }

        if ($exam->questions()->count() === 0) {
            return response()->json([
                'message' => 'O exame precisa de ter pelo menos uma pergunta.',
            ], 422);
        }

        $exam->update(['status' => 'published']);

        return response()->json([
            'id' => $exam->id,
            'status' => $exam->status,
        ]);
    }

    public function stats(Request $request, Exam $exam): JsonResponse
    {
        $teacher = $request->user()->teacherProfile;

        if ($exam->teacher_id !== $teacher->id) {
            return response()->json([
                'message' => 'Acesso negado.',
            ], 403);
        }

        $attempts = ExamAttempt::where('exam_id', $exam->id)
            ->where('status', 'completed')
            ->with('student.user')
            ->get();

        $distribution = [
            '0-50' => $attempts->where('score', '<', 50)->count(),
            '50-70' => $attempts->whereBetween('score', [50, 69])->count(),
            '70-90' => $attempts->whereBetween('score', [70, 89])->count(),
            '90-100' => $attempts->where('score', '>=', 90)->count(),
        ];

        return response()->json([
            'totalStudents' => $exam->classGroup?->students()->count() ?? 0,
            'completedStudents' => $attempts->count(),
            'avgScore' => round($attempts->avg('score'), 1),
            'distribution' => $distribution,
        ]);
    }
}

