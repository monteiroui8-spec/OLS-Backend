<?php

namespace App\Http\Controllers\Api\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Grade;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TeacherGradeController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacherProfile;

        $grades = Grade::where('teacher_id', $teacher->id)
            ->with(['student.user', 'course'])
            ->orderByDesc('date')
            ->paginate($request->integer('limit', 20));

        $data = $grades->map(function (Grade $grade) {
            return [
                'id' => $grade->id,
                'title' => $grade->title,
                'type' => $grade->type,
                'grade' => $grade->grade,
                'max_grade' => $grade->max_grade,
                'date' => $grade->date,
                'student' => [
                    'name' => $grade->student?->user?->full_name,
                ],
                'course' => $grade->course?->getTitle(app()->getLocale()),
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'total' => $grades->total(),
                'page' => $grades->currentPage(),
                'last_page' => $grades->lastPage(),
            ],
        ]);
    }
}

