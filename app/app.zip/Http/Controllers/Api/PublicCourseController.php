<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ClassGroup;
use App\Models\ClassSchedule;
use App\Models\Course;
use App\Models\StudentProfile;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class PublicCourseController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $lang = $request->header('Accept-Language', 'pt');

        $courses = Cache::remember(
            'public_courses_'.$lang,
            now()->addMinutes(30),
            function () use ($lang) {
                return Course::active()
                    ->visibleOnSite()
                    ->orderBy('service_type')
                    ->get()
                    ->map(function (Course $course) use ($lang) {
                        $title = $lang === 'en' ? $course->title_en : $course->title_pt;
                        $description = $lang === 'en' ? $course->description_en : $course->description_pt;

                        return [
                            'id' => $course->id,
                            'slug' => $course->slug,
                            'title' => $title,
                            'description' => $description,
                            'level' => $course->level,
                            'serviceType' => $course->service_type,
                            'flyerUrl' => $course->flyer_url,
                            'imageUrl' => $course->image_url,
                            'duration' => $course->duration,
                            'startDate' => $course->start_date?->toDateString(),
                            'availableSeats' => $course->available_seats,
                            'prerequisites' => $course->prerequisites,
                            'syllabus' => $course->syllabus,
                            'requiredMaterial' => $course->required_material,
                            'tags' => $course->tags ?? [],
                            'prices' => [
                                'AOA' => $course->price_aoa,
                                'EUR' => $course->price_eur,
                                'USD' => $course->price_usd,
                            ],
                        ];
                    });
            }
        );

        return response()->json([
            'data' => $courses,
        ]);
    }

    public function classes(Course $course): JsonResponse
    {
        $classes = ClassGroup::with('schedules')
            ->where('course_id', $course->id)
            ->where('is_active', true)
            ->orderByDesc('year')
            ->orderBy('name')
            ->get();

        $data = $classes->map(function (ClassGroup $class) {
            return [
                'id' => $class->id,
                'name' => $class->name,
                'year' => $class->year,
                'capacity' => $class->capacity,
                'room' => $class->room,
                'schedules' => $class->schedules->map(function (ClassSchedule $schedule) {
                    return [
                        'id' => $schedule->id,
                        'day_of_week' => $schedule->day_of_week,
                        'start_time' => $schedule->start_time,
                        'end_time' => $schedule->end_time,
                        'room' => $schedule->room,
                    ];
                })->values(),
            ];
        })->values();

        return response()->json(['data' => $data]);
    }

    public function stats(): JsonResponse
    {
        $payload = Cache::remember(
            'public_stats',
            now()->addHour(),
            function () {
                return [
                    'studentsFormed' => StudentProfile::count(),
                    'approvalRate' => 98,
                    'averageRating' => 5.0,
                    'activeClasses' => ClassGroup::active()->count(),
                ];
            }
        );

        return response()->json($payload);
    }

    public function rates(): JsonResponse
    {
        $payload = Cache::remember(
            'exchange_rates',
            now()->addHour(),
            function () {
                return [
                    'AOA_EUR' => 0.001,
                    'AOA_USD' => 0.001,
                    'updatedAt' => now(),
                ];
            }
        );

        return response()->json($payload);
    }

    public function enrollmentRequest(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'first_name' => ['required', 'string'],
            'last_name' => ['required', 'string'],
            'email' => ['required', 'email', 'unique:users,email'],
            'phone' => ['required', 'string'],
            'service_type' => ['required', 'string'],
            'country' => ['nullable', 'string', 'size:2'],
            'language' => ['nullable', 'in:pt,en'],
            'currency' => ['nullable', 'in:AOA,EUR,USD'],
        ]);

        $user = User::create([
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'password' => Hash::make(Str::random(16)),
            'role' => 'student',
            'status' => 'pending',
            'country' => $validated['country'] ?? 'AO',
            'preferred_language' => $validated['language'] ?? 'pt',
            'preferred_currency' => $validated['currency'] ?? 'AOA',
        ]);

        Role::findOrCreate('student', 'web');
        $user->assignRole('student');

        StudentProfile::create([
            'user_id' => $user->id,
            'student_code' => 'PENDING-'.Str::upper(Str::random(6)),
            'current_level' => null,
            'enrollment_date' => now()->toDateString(),
        ]);

        return response()->json([
            'message' => 'Inscrição recebida.',
        ], 201);
    }
}
