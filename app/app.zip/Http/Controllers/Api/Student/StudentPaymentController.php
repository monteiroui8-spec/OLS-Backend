<?php

namespace App\Http\Controllers\Api\Student;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;

class StudentPaymentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $student = $request->user()->studentProfile;
        $currency = $request->header('X-Currency', $request->user()->preferred_currency);

        $payments = Payment::forStudent($student->id)
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->get('status')))
            ->orderByDesc('due_date')
            ->paginate($request->integer('limit', 20));

        $data = $payments->map(function (Payment $payment) use ($currency) {
            return [
                'id' => $payment->id,
                'description' => $payment->description,
                'amount' => $payment->amount,
                'currency' => $payment->currency,
                'due_date' => $payment->due_date,
                'paid_at' => $payment->paid_at,
                'status' => $payment->status,
                'invoice_number' => $payment->invoice_number,
            ];
        });

        $all = Payment::forStudent($student->id)->get();

        $stats = [
            'totalPaid' => $all->where('status', 'paid')->sum('amount'),
            'totalPending' => $all->whereIn('status', ['pending', 'overdue'])->sum('amount'),
            'totalOverdue' => $all->where('status', 'overdue')->sum('amount'),
            'total' => $all->count(),
            'currency' => $currency,
        ];

        return response()->json([
            'data' => $data,
            'meta' => [
                'total' => $payments->total(),
                'page' => $payments->currentPage(),
                'last_page' => $payments->lastPage(),
            ],
            'stats' => $stats,
        ]);
    }

    public function receipt(Request $request, Payment $payment): Response
    {
        $student = $request->user()->studentProfile;

        if ($payment->student_id !== $student->id) {
            abort(403);
        }

        if ($payment->receipt_url) {
            return response()->redirectTo($payment->receipt_url);
        }

        $payment->load('student.user', 'course');

        $pdf = Pdf::loadView('pdf.payment-receipt', [
            'payment' => $payment,
        ])->setPaper('a4');

        $key = 'receipts/'.$payment->invoice_number.'.pdf';
        Storage::disk('s3')->put($key, $pdf->output(), 'private');

        $publicUrl = Storage::disk('s3')->url($key);
        $payment->update(['receipt_url' => $publicUrl]);

        return $pdf->download($payment->invoice_number.'.pdf');
    }
}

