<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Notifications\PaymentConfirmedNotification;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AdminPaymentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $payments = Payment::with('student.user', 'course')
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->get('status')))
            ->orderByDesc('due_date')
            ->paginate($request->integer('limit', 20));

        $data = $payments->map(function (Payment $payment) {
            return [
                'id' => $payment->id,
                'invoice_number' => $payment->invoice_number,
                'student' => $payment->student?->user?->full_name,
                'description' => $payment->description,
                'amount' => $payment->amount,
                'currency' => $payment->currency,
                'status' => $payment->status,
                'due_date' => $payment->due_date,
                'paid_at' => $payment->paid_at,
                'method' => $payment->method,
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'total' => $payments->total(),
                'page' => $payments->currentPage(),
                'last_page' => $payments->lastPage(),
            ],
        ]);
    }

    public function update(Request $request, Payment $payment): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['sometimes', 'in:paid,pending,overdue,cancelled,refunded'],
            'paid_at' => ['required_if:status,paid', 'date'],
            'method' => ['required_if:status,paid', 'in:credit_card,bank_transfer,mpesa,multicaixa,cash,other'],
            'transaction_ref' => ['nullable', 'string', 'max:191'],
        ]);

        $payment->update($validated);

        if (($validated['status'] ?? null) === 'paid' && $payment->student && $payment->student->user) {
            $payment->student->user->notify(new PaymentConfirmedNotification($payment));
        }

        return response()->json([
            'id' => $payment->id,
            'status' => $payment->status,
            'paid_at' => $payment->paid_at,
        ]);
    }

    public function export(Request $request): StreamedResponse
    {
        $validated = $request->validate([
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
            'status' => ['nullable', 'in:paid,pending,overdue,cancelled,refunded'],
        ]);

        $filename = 'pagamentos-'.now()->format('Y-m-d').'.csv';

        return response()->streamDownload(function () use ($validated) {
            $payments = Payment::with('student.user')
                ->whereBetween('due_date', [$validated['start_date'], $validated['end_date']])
                ->when($validated['status'] ?? null, fn ($q, $status) => $q->where('status', $status))
                ->orderBy('due_date')
                ->cursor();

            $header = ['Nº Fatura', 'Aluno', 'Descrição', 'Valor', 'Moeda', 'Estado', 'Data Vencimento', 'Data Pagamento', 'Método'];
            echo implode(',', $header)."\n";

            foreach ($payments as $p) {
                echo implode(',', [
                    $p->invoice_number,
                    $p->student?->user?->full_name,
                    $p->description,
                    $p->amount,
                    $p->currency,
                    $p->status,
                    $p->due_date,
                    $p->paid_at ?? '',
                    $p->method ?? '',
                ])."\n";
            }
        }, $filename, [
            'Content-Type' => 'text/csv',
        ]);
    }
}
