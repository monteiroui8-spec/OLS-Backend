<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Exam;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminExamController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $exams = Exam::with(['classGroup.course', 'teacher.user'])
            ->withCount('questions')
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->get('status')))
            ->orderByDesc('created_at')
            ->paginate($request->integer('limit', 20));

        $data = $exams->map(function (Exam $exam) {
            return [
                'id'             => $exam->id,
                'title'          => $exam->title,
                'status'         => $exam->status,
                'duration'       => $exam->duration,
                'max_attempts'   => $exam->max_attempts,
                'due_date'       => $exam->due_date?->toDateString(),
                'questionCount'  => $exam->questions_count,
                'classGroupName' => $exam->classGroup?->name ?? '—',
                'course'         => $exam->classGroup?->course?->title_pt ?? '—',
                'teacher'        => $exam->teacher?->user?->full_name ?? '—',
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'total'     => $exams->total(),
                'page'      => $exams->currentPage(),
                'last_page' => $exams->lastPage(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'title'          => ['required', 'string', 'max:191'],
            'teacher_id'     => ['required', 'exists:teacher_profiles,id'],
            'class_group_id' => ['nullable', 'exists:class_groups,id'],
            'course_id'      => ['nullable', 'exists:courses,id'],
            'duration'       => ['required', 'integer', 'min:1'],
            'max_attempts'   => ['nullable', 'integer', 'min:1'],
            'due_date'       => ['nullable', 'date'],
            'pass_score'     => ['nullable', 'integer', 'min:0', 'max:100'],
            'questions'      => ['required', 'array', 'min:1'],
            'questions.*.text'    => ['required', 'string'],
            'questions.*.type'    => ['required', 'in:multiple_choice,true_false'],
            'questions.*.options' => ['required', 'array'],
            'questions.*.correct' => ['required', 'integer'],
            'questions.*.points'  => ['nullable', 'integer', 'min:1'],
        ]);

        $exam = DB::transaction(function () use ($validated) {
            $exam = Exam::create([
                'title'          => $validated['title'],
                'teacher_id'     => $validated['teacher_id'],
                'class_group_id' => $validated['class_group_id'] ?? null,
                'course_id'      => $validated['course_id'] ?? null,
                'duration'       => $validated['duration'],
                'max_attempts'   => $validated['max_attempts'] ?? 1,
                'status'         => 'draft',
                'due_date'       => $validated['due_date'] ?? null,
                'pass_score'     => $validated['pass_score'] ?? 50,
                'total_points'   => 0,
            ]);

            $totalPoints = 0;
            foreach ($validated['questions'] as $index => $q) {
                $points = $q['points'] ?? 10;
                $exam->questions()->create([
                    'text'    => $q['text'],
                    'type'    => $q['type'],
                    'options' => $q['options'],
                    'correct' => $q['correct'],
                    'points'  => $points,
                    'order'   => $index + 1,
                ]);
                $totalPoints += $points;
            }

            $exam->update(['total_points' => $totalPoints]);

            return $exam;
        });

        return response()->json([
            'id'     => $exam->id,
            'title'  => $exam->title,
            'status' => $exam->status,
        ], 201);
    }

    public function publish(Exam $exam): JsonResponse
    {
        if ($exam->questions()->count() === 0) {
            return response()->json(['message' => 'O exame precisa de ter pelo menos uma pergunta.'], 422);
        }

        $exam->update(['status' => 'published']);

        return response()->json(['id' => $exam->id, 'status' => $exam->status]);
    }

    public function destroy(Exam $exam): JsonResponse
    {
        $exam->delete();

        return response()->json(null, 204);
    }
}
