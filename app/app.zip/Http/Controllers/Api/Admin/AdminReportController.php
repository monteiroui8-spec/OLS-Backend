<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\ClassGroup;
use App\Models\Enrollment;
use App\Models\Payment;
use App\Models\StudentProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdminReportController extends Controller
{
    public function students(Request $request): JsonResponse
    {
        $total = StudentProfile::count();
        $activeEnrollments = Enrollment::where('status', 'active')->count();

        $byLevel = StudentProfile::selectRaw('current_level, count(*) as total')
            ->groupBy('current_level')
            ->get();

        return response()->json([
            'totalStudents' => $total,
            'activeEnrollments' => $activeEnrollments,
            'byLevel' => $byLevel,
        ]);
    }

    public function payments(Request $request): JsonResponse
    {
        $start = $request->get('start_date', now()->startOfMonth()->toDateString());
        $end = $request->get('end_date', now()->endOfMonth()->toDateString());

        $payments = Payment::whereBetween('due_date', [$start, $end])->get();

        $summary = [
            'total' => $payments->count(),
            'paid' => $payments->where('status', 'paid')->count(),
            'pending' => $payments->where('status', 'pending')->count(),
            'overdue' => $payments->where('status', 'overdue')->count(),
            'amountPaid' => $payments->where('status', 'paid')->sum('amount'),
        ];

        return response()->json($summary);
    }

    public function attendance(Request $request): JsonResponse
    {
        $start = $request->get('start_date', now()->subMonth()->toDateString());
        $end = $request->get('end_date', now()->toDateString());

        $records = Attendance::whereBetween('date', [$start, $end])->get();

        $total = $records->count();
        $present = $records->where('status', 'present')->count();
        $absent = $records->where('status', 'absent')->count();

        $classes = ClassGroup::withCount(['attendances' => function ($q) use ($start, $end) {
            $q->whereBetween('date', [$start, $end])->where('status', 'absent');
        }])->orderByDesc('attendances_count')->take(5)->get();

        return response()->json([
            'totalRecords' => $total,
            'present' => $present,
            'absent' => $absent,
            'topClassesByAbsences' => $classes->map(function (ClassGroup $class) {
                return [
                    'id' => $class->id,
                    'name' => $class->name,
                    'absences' => $class->attendances_count,
                ];
            }),
        ]);
    }
}

