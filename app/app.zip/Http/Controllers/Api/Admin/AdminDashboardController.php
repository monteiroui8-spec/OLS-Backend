<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ClassGroup;
use App\Models\Payment;
use App\Models\StudentProfile;
use App\Models\TeacherProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
use Spatie\Activitylog\Models\Activity;

class AdminDashboardController extends Controller
{
    public function index(): JsonResponse
    {
        $data = Cache::remember(
            'admin_dashboard',
            now()->addMinutes(5),
            function () {
                $now = now();
                $monthStart = $now->copy()->startOfMonth();
                $lastMonthStart = $now->copy()->subMonth()->startOfMonth();
                $lastMonthEnd = $now->copy()->subMonth()->endOfMonth();

                $revenueThisMonth = Payment::where('status', 'paid')
                    ->whereBetween('paid_at', [$monthStart, $now])
                    ->sum('amount');

                $revenueLastMonth = Payment::where('status', 'paid')
                    ->whereBetween('paid_at', [$lastMonthStart, $lastMonthEnd])
                    ->sum('amount');

                $revenueChange = $revenueLastMonth > 0
                    ? round(($revenueThisMonth - $revenueLastMonth) / $revenueLastMonth * 100, 1)
                    : 0;

                $financialChart = collect(range(5, 0))->map(function (int $monthsAgo) {
                    $month = now()->subMonths($monthsAgo);

                    return [
                        'month' => $month->format('M'),
                        'Revenue' => Payment::where('status', 'paid')
                            ->whereMonth('paid_at', $month->month)
                            ->whereYear('paid_at', $month->year)
                            ->sum('amount'),
                        'Expenses' => 0,
                    ];
                });

                $activities = Activity::with('causer')
                    ->latest()
                    ->take(10)
                    ->get()
                    ->map(function (Activity $activity) {
                        return [
                            'text' => $activity->description,
                            'time' => $activity->created_at->diffForHumans(),
                        ];
                    });

                $overdueCount = Payment::where('status', 'overdue')->count();

                $alerts = [];

                if ($overdueCount > 0) {
                    $alerts[] = [
                        'text' => $overdueCount.' pagamento(s) em atraso.',
                        'type' => 'error',
                    ];
                }

                $fullClasses = ClassGroup::where('is_active', true)
                    ->get()
                    ->filter(function (ClassGroup $classGroup) {
                        return ! $classGroup->hasCapacity();
                    });

                if ($fullClasses->count() > 0) {
                    $alerts[] = [
                        'text' => $fullClasses->count().' turma(s) com capacidade máxima atingida.',
                        'type' => 'info',
                    ];
                }

                return [
                    'stats' => [
                        'totalStudents' => StudentProfile::count(),
                        'totalTeachers' => TeacherProfile::count(),
                        'activeClasses' => ClassGroup::where('is_active', true)->count(),
                        'monthlyRevenue' => [
                            'AOA' => $revenueThisMonth,
                        ],
                        'revenueChange' => $revenueChange,
                    ],
                    'financialChart' => $financialChart,
                    'recentActivities' => $activities,
                    'paymentSummary' => [
                        'paid' => Payment::where('status', 'paid')
                            ->whereMonth('due_date', $now->month)
                            ->count(),
                        'pending' => Payment::where('status', 'pending')->count(),
                        'overdue' => Payment::where('status', 'overdue')->count(),
                    ],
                    'alerts' => $alerts,
                ];
            }
        );

        return response()->json($data);
    }
}

