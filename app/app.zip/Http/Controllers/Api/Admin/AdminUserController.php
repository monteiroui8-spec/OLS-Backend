<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\AdminProfile;
use App\Models\StudentProfile;
use App\Models\TeacherProfile;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class AdminUserController extends Controller
{
    public function index(Request $request)
    {
        $users = QueryBuilder::for(User::class)
            ->allowedFilters([
                'role',
                'status',
                AllowedFilter::callback('search', function ($query, $value) {
                    $query->search($value);
                }),
            ])
            ->allowedSorts(['first_name', 'email', 'created_at', 'last_login_at'])
            ->with(['studentProfile', 'teacherProfile', 'adminProfile'])
            ->withTrashed()
            ->paginate($request->integer('limit', 20));

        return UserResource::collection($users);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'first_name'         => ['required', 'string', 'max:80'],
            'last_name'          => ['required', 'string', 'max:80'],
            'email'              => ['required', 'email', 'max:191', 'unique:users,email'],
            'phone'              => ['nullable', 'string', 'max:30'],
            'password'           => ['nullable', 'string', 'min:8'],
            'role'               => ['required', 'in:admin,teacher,student'],
            'status'             => ['required', 'in:active,inactive,pending,suspended'],
            'country'            => ['nullable', 'string', 'size:2'],
            'preferred_language' => ['nullable', 'in:pt,en'],
            'preferred_currency' => ['nullable', 'in:AOA,EUR,USD'],
        ]);

        $password = $validated['password'] ?? Str::random(12);

        $user = DB::transaction(function () use ($validated, $password) {
            $user = User::create([
                'first_name'         => $validated['first_name'],
                'last_name'          => $validated['last_name'],
                'email'              => $validated['email'],
                'phone'              => $validated['phone'] ?? null,
                'password'           => Hash::make($password),
                'role'               => $validated['role'],
                'status'             => $validated['status'],
                'country'            => $validated['country'] ?? 'AO',
                'preferred_language' => $validated['preferred_language'] ?? 'pt',
                'preferred_currency' => $validated['preferred_currency'] ?? 'AOA',
            ]);

            $user->assignRole($user->role);

            // Create the role-specific profile so all student/teacher/admin
            // endpoints can resolve $request->user()->studentProfile etc.
            $this->createProfileForRole($user);

            return $user;
        });

        return response()->json(new UserResource($user->load(['studentProfile', 'teacherProfile', 'adminProfile'])), 201);
    }

    public function update(Request $request, User $user): JsonResponse
    {
        $validated = $request->validate([
            'first_name'         => ['sometimes', 'string', 'max:80'],
            'last_name'          => ['sometimes', 'string', 'max:80'],
            'email'              => ['sometimes', 'email', 'max:191', 'unique:users,email,'.$user->id],
            'phone'              => ['sometimes', 'nullable', 'string', 'max:30'],
            'role'               => ['sometimes', 'in:admin,teacher,student'],
            'status'             => ['sometimes', 'in:active,inactive,pending,suspended'],
            'country'            => ['sometimes', 'string', 'size:2'],
            'preferred_language' => ['sometimes', 'in:pt,en'],
            'preferred_currency' => ['sometimes', 'in:AOA,EUR,USD'],
        ]);

        $beforeRole = $user->role;
        $user->update($validated);

        if (array_key_exists('role', $validated) && $validated['role'] !== $beforeRole) {
            $user->syncRoles([$validated['role']]);

            // Ensure the new role has a profile record
            $this->createProfileForRole($user->fresh());
        }

        return response()->json(new UserResource($user->fresh()));
    }

    public function destroy(User $user): JsonResponse
    {
        $user->delete();

        return response()->json(null, 204);
    }

    public function resetPassword(Request $request, User $user): JsonResponse
    {
        $validated = $request->validate([
            'new_password' => ['nullable', 'string', 'min:8'],
        ]);

        $newPassword = $validated['new_password'] ?? Str::random(12);

        $user->update([
            'password' => Hash::make($newPassword),
        ]);

        $user->tokens()->delete();

        return response()->json([
            'message' => 'Password redefinida.',
        ]);
    }

    // ─── Helpers ────────────────────────────────────────────────────────────────

    /**
     * Create the role-specific profile record for a user if it does not exist yet.
     * Without this, all student/teacher/admin API endpoints return 500 because
     * they call $user->studentProfile->id and the relation is null.
     */
    private function createProfileForRole(User $user): void
    {
        match ($user->role) {
            'student' => StudentProfile::firstOrCreate(
                ['user_id' => $user->id],
                [
                    'student_code'    => $this->generateCode('student'),
                    'enrollment_date' => now()->toDateString(),
                ]
            ),
            'teacher' => TeacherProfile::firstOrCreate(
                ['user_id' => $user->id],
                [
                    'teacher_code' => $this->generateCode('teacher'),
                    'hire_date'    => now()->toDateString(),
                ]
            ),
            'admin' => AdminProfile::firstOrCreate(
                ['user_id' => $user->id],
                [
                    'admin_code' => $this->generateCode('admin'),
                ]
            ),
            default => null,
        };
    }

    private function generateCode(string $role): string
    {
        $year   = now()->year;
        $prefix = match ($role) {
            'student' => "OLS-{$year}",
            'teacher' => 'TCH',
            'admin'   => 'ADM',
            default   => strtoupper($role),
        };

        $count = match ($role) {
            'student' => StudentProfile::whereYear('created_at', $year)->count() + 1,
            'teacher' => TeacherProfile::count() + 1,
            'admin'   => AdminProfile::count() + 1,
            default   => 1,
        };

        return $prefix.'-'.str_pad($count, 4, '0', STR_PAD_LEFT);
    }
}