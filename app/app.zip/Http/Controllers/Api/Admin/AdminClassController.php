<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ChatConversation;
use App\Models\ClassGroup;
use App\Models\ClassSchedule;
use App\Models\Enrollment;
use App\Models\StudentProfile;
use App\Models\TeacherProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminClassController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $classes = ClassGroup::with(['course', 'teacher.user', 'schedules', 'students'])
            ->when($request->filled('year'), fn ($q) => $q->where('year', $request->integer('year')))
            ->paginate($request->integer('limit', 20));

        $data = $classes->map(function (ClassGroup $class) {
            return [
                'id' => $class->id,
                'name' => $class->name,
                'year' => $class->year,
                'capacity' => $class->capacity,
                'is_active' => $class->is_active,
                'course' => [
                    'id' => $class->course?->id,
                    'title_pt' => $class->course?->title_pt,
                    'title_en' => $class->course?->title_en,
                    'level' => $class->course?->level,
                ],
                'teacher' => $class->teacher?->user?->full_name,
                'students_count' => $class->students->count(),
                'schedules' => $class->schedules->map(function (ClassSchedule $schedule) {
                    return [
                        'id' => $schedule->id,
                        'day_of_week' => $schedule->day_of_week,
                        'start_time' => $schedule->start_time,
                        'end_time' => $schedule->end_time,
                        'room' => $schedule->room,
                    ];
                }),
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'total' => $classes->total(),
                'page' => $classes->currentPage(),
                'last_page' => $classes->lastPage(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:191'],
            'course_id' => ['required', 'exists:courses,id'],
            'teacher_id' => ['required', 'exists:teacher_profiles,id'],
            'year' => ['required', 'integer'],
            'capacity' => ['required', 'integer', 'min:1'],
            'room' => ['nullable', 'string', 'max:50'],
            'schedules' => ['nullable', 'array'],
            'schedules.*.day_of_week' => ['required_with:schedules', 'integer', 'min:0', 'max:6'],
            'schedules.*.start_time' => ['required_with:schedules', 'date_format:H:i'],
            'schedules.*.end_time' => ['required_with:schedules', 'date_format:H:i', 'after:schedules.*.start_time'],
            'schedules.*.room' => ['nullable', 'string', 'max:50'],
        ]);

        $class = DB::transaction(function () use ($validated) {
            $class = ClassGroup::create([
                'name' => $validated['name'],
                'course_id' => $validated['course_id'],
                'teacher_id' => $validated['teacher_id'],
                'year' => $validated['year'],
                'capacity' => $validated['capacity'],
                'room' => $validated['room'] ?? null,
                'is_active' => true,
            ]);

            if (! empty($validated['schedules'])) {
                foreach ($validated['schedules'] as $schedule) {
                    $conflict = ClassSchedule::whereHas('classGroup', function ($q) use ($validated) {
                        $q->where('teacher_id', $validated['teacher_id']);
                    })
                        ->where('day_of_week', $schedule['day_of_week'])
                        ->where(function ($q) use ($schedule) {
                            $q->whereBetween('start_time', [$schedule['start_time'], $schedule['end_time']])
                                ->orWhereBetween('end_time', [$schedule['start_time'], $schedule['end_time']]);
                        })
                        ->exists();

                    if ($conflict) {
                        throw new \RuntimeException('Conflito de horário para este professor.');
                    }

                    $class->schedules()->create($schedule);
                }
            }

            // ── Criar grupo de chat automaticamente ──────────────────────
            $conversation = ChatConversation::create([
                'type'     => 'group',
                'name'     => $class->name,
                'class_id' => $class->id,
            ]);

            // Adicionar o professor como participante
            $teacher = TeacherProfile::with('user')->find($validated['teacher_id']);
            if ($teacher?->user) {
                $conversation->participants()->attach($teacher->user->id, ['joined_at' => now()]);
            }

            return $class;
        });

        $class->load(['course', 'teacher.user', 'schedules', 'students']);

        return response()->json([
            'data' => [
                'id' => $class->id,
                'name' => $class->name,
            ],
        ], 201);
    }

    public function addStudent(Request $request, ClassGroup $class): JsonResponse
    {
        if (! $class->hasCapacity()) {
            return response()->json([
                'message' => 'Esta turma já atingiu o limite de alunos.',
            ], 422);
        }

        $validated = $request->validate([
            'student_id' => ['required', 'exists:student_profiles,id'],
        ]);

        $student = StudentProfile::findOrFail($validated['student_id']);

        if ($class->students()->where('student_id', $student->id)->exists()) {
            return response()->json([
                'message' => 'O aluno já está inscrito nesta turma.',
            ], 422);
        }

        Enrollment::create([
            'student_id' => $student->id,
            'course_id' => $class->course_id,
            'class_group_id' => $class->id,
            'start_date' => now()->toDateString(),
            'status' => 'active',
        ]);

        // ── Adicionar aluno ao grupo de chat da turma ─────────────────────
        $conversation = ChatConversation::where('class_id', $class->id)->first();
        if ($conversation && $student->user_id) {
            $conversation->participants()->syncWithoutDetaching([
                $student->user_id => ['joined_at' => now()],
            ]);
        }

        return response()->json([
            'message' => 'Aluno inscrito com sucesso.',
        ]);
    }

    public function update(Request $request, ClassGroup $class): JsonResponse
{
    $validated = $request->validate([
        'name'       => ['sometimes', 'string', 'max:191'],
        'teacher_id' => ['sometimes', 'exists:teacher_profiles,id'],
        'capacity'   => ['sometimes', 'integer', 'min:1'],
        'room'       => ['nullable', 'string', 'max:50'],
        'is_active'  => ['sometimes', 'boolean'],
    ]);

    $class->update($validated);

    return response()->json(['message' => 'Turma actualizada.']);
}

public function addSchedule(Request $request, ClassGroup $class): JsonResponse
{
    $validated = $request->validate([
        'day_of_week' => ['required', 'integer', 'min:0', 'max:6'],
        'start_time'  => ['required', 'date_format:H:i'],
        'end_time'    => ['required', 'date_format:H:i', 'after:start_time'],
        'room'        => ['nullable', 'string', 'max:50'],
    ]);

    $conflict = ClassSchedule::whereHas('classGroup', fn ($q) => $q->where('teacher_id', $class->teacher_id))
        ->where('day_of_week', $validated['day_of_week'])
        ->where(function ($q) use ($validated) {
            $q->whereBetween('start_time', [$validated['start_time'], $validated['end_time']])
              ->orWhereBetween('end_time', [$validated['start_time'], $validated['end_time']]);
        })->exists();

    if ($conflict) {
        return response()->json(['message' => 'Conflito de horário para este professor.'], 422);
    }

    $schedule = $class->schedules()->create($validated);

    return response()->json(['id' => $schedule->id, ...$validated], 201);
}

public function removeSchedule(ClassGroup $class, ClassSchedule $schedule): JsonResponse
{
    abort_if($schedule->class_group_id !== $class->id, 404);
    $schedule->delete();
    return response()->json(null, 204);
}

}