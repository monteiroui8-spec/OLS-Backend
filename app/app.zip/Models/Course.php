<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Concerns\HasUlids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Course extends Model {
    use HasUlids, SoftDeletes;
    protected $fillable = [
        'slug',
        'title_pt',
        'title_en',
        'description_pt',
        'description_en',
        'prerequisites',
        'level',
        'service_type',
        'duration',
        'start_date',
        'available_seats',
        'responsible_teacher_id',
        'syllabus',
        'required_material',
        'image_url',
        'flyer_url',
        'price_aoa',
        'price_eur',
        'price_usd',
        'is_active',
        'visibility_status',
        'published_at',
        'meta_description',
        'tags',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'price_aoa' => 'decimal:2',
        'price_eur' => 'decimal:2',
        'price_usd' => 'decimal:2',
        'tags' => 'array',
        'start_date' => 'date',
        'published_at' => 'datetime',
        'available_seats' => 'integer',
    ];

    public function classes(): HasMany { return $this->hasMany(ClassGroup::class); }
    public function enrollments(): HasMany { return $this->hasMany(Enrollment::class); }
    public function documents(): HasMany { return $this->hasMany(Document::class); }
    public function responsibleTeacher(): BelongsTo { return $this->belongsTo(TeacherProfile::class, 'responsible_teacher_id'); }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeVisibleOnSite($query)
    {
        return $query
            ->whereIn('visibility_status', ['published', 'scheduled'])
            ->where(function ($q) {
                $q->whereNull('published_at')->orWhere('published_at', '<=', now());
            });
    }

    public function getTitle(string $lang = 'pt'): string
    {
        return $lang === 'en' ? $this->title_en : $this->title_pt;
    }

    public function getPriceForCurrency(string $currency): float
    {
        return match($currency) {
            'EUR'   => $this->price_eur,
            'USD'   => $this->price_usd,
            default => $this->price_aoa,
        };
    }
}
