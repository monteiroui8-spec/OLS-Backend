<?php

namespace App\Jobs;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendWelcomeEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 60;

    public function __construct(public readonly User $user) {}

    public function handle(): void
    {
        Mail::send(
            'emails.welcome',
            ['user' => $this->user],
            function ($message) {
                $message
                    ->to($this->user->email, $this->user->full_name)
                    ->subject('Bem-vindo(a) à Olsangola Corporation!');
            }
        );
    }
}
